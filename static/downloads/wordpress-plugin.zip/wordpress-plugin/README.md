## Cleavr plugin for WordPress

### Setting up:
1. Clone the project
2. Use any editor to edit it
3. Bump the version in `cleavr.php` file
4. To test it locally, just create a zip of the whold folder (right-click -> compress on the macOS)
5. Go to plugin section in WordPress instance and upload your zip folder. Overwrite when asked.

